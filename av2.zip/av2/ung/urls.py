from django.contrib import admin
from django.urls import path
from product.views import ProdutoCreateView, ProdutoDeleteView, ProdutoDetailView, ProdutoUpdateView, ProdutoListView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', ProdutoListView.as_view(), name='produto_list'),  # Corrigido 'as.view()' para 'as_view()'
    path('product/<int:pk>/', ProdutoDetailView.as_view(), name='produto_detail'),  # Corrigido 'as.view()' para 'as_view()'
    path('product/add/', ProdutoCreateView.as_view(), name='produto_add'),  # Corrigido '<add>' para 'add/'
    path('product/<int:pk>/update/', ProdutoUpdateView.as_view(), name='produto_update'),  # Corrigido 'as.view()' para 'as_view()'
    path('product/<int:pk>/delete/', ProdutoDeleteView.as_view(), name='produto_delete'),  # Corrigido 'as.view()' para 'as_view()'
]
