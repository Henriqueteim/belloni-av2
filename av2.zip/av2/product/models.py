from django.db import models

class Produto(models.Model):
    nome = models.CharField(max_length=200, null=False)
    descricao = models.CharField(max_length=500, null=False)  # Adicionei max_length à descricao
    valor = models.FloatField(null=False)  # Corrigi a falta de '=' entre 'valor' e 'models.FloatField'
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_modificacao = models.DateTimeField(auto_now=True)  # Corrigi 'model.DateTimerField' para 'models.DateTimeField'

    def __str__(self):
        return self.nome
