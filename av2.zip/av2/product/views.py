from django.contrib.auth.forms import AuthenticationForm  # Corrigido 'Autenticationform' para 'AuthenticationForm'
from django.views.generic import ListView, DetailView, DeleteView, CreateView, UpdateView  # Corrigido 'DetaisView' para 'DetailView'
from django.urls import reverse_lazy
from .models import Produto

class ProdutoListView(ListView):
    model = Produto  # Corrigido 'moldel' para 'model'
    template_name = 'produto_list.html'

class ProdutoDetailView(DetailView):
    model = Produto  # Corrigido 'moldel' para 'model'
    template_name = 'produto_detail.html'

class ProdutoCreateView(CreateView):
    model = Produto  # Corrigido 'moldel' para 'model'
    template_name = 'produto_form.html'
    fields = ['nome', 'descricao', 'valor']
    success_url = reverse_lazy('produto_list')  # Corrigido 'sucess_url' para 'success_url'

class ProdutoUpdateView(UpdateView):
    model = Produto  # Corrigido 'moldel' para 'model'
    template_name = 'produto_form.html'
    fields = ['nome', 'descricao', 'valor']
    success_url = reverse_lazy('produto_list')  # Corrigido 'sucess_url' para 'success_url'

class ProdutoDeleteView(DeleteView):
    model = Produto  # Corrigido 'moldel' para 'model'
    template_name = 'produto_confirm_delete.html'
    fields = ['nome', 'descricao', 'valor']
    success_url = reverse_lazy('produto_list')  # Corrigido 'sucess_url' para 'success_url'
